package com.example.beans;

public class Salary {

	private int id;
	private String sal_month;
	private int sal_year;
	private int amount;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSal_month() {
		return sal_month;
	}
	public void setSal_month(String sal_month) {
		this.sal_month = sal_month;
	}
	public int getSal_year() {
		return sal_year;
	}
	public void setSal_year(int sal_year) {
		this.sal_year = sal_year;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	
	
	
}
